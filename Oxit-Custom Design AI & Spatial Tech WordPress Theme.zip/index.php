<?php get_header();?>
<section id="one">
      <div id="hero">
        <div id="left">
          <h1>Step into tomorrow</h1>
          <p>Innovating AI & Spatial Tech Solutions for a Connected Future!</p>
        </div>
        <div id="right">
          <img src="<?php echo get_theme_file_uri('/images/hero-image.png');?>" alt="" srcset="" />
        </div>
      </div>
    </section>
    <section id="two">
      <div id="services">
        <div id="service1">
          <img src="<?php echo get_theme_file_uri('/images/service-1.png');?>" alt="" srcset="" />
        </div>
        <div id="service2">
          <img src="<?php echo get_theme_file_uri('/images/service-2.png');?>" alt="" srcset="" />
        </div>
        <div id="service3">
          <img src="<?php echo get_theme_file_uri('/images/service-3.png');?>" alt="" srcset="" />
        </div>
        <div id="service4">
          <img src="<?php echo get_theme_file_uri('/images/service-4.png');?>" alt="" srcset="" />
        </div>
        <div id="service5">
          <img src="<?php echo get_theme_file_uri('/images/service-5.png');?>" alt="" srcset="" />
        </div>
      </div>
    </section>
    <section id="three">
      <div id="about">
        <h1>About Us</h1>
        <p>
          Our company primarily focuses on the development of Spatial Computing
          solutions (VR, AR, MR), industrial visualization technologies,
          autonomous robotics, along with computer vison and artificial
          intelligence. We have developed our team of experts and professional
          resources accordingly. Our goal is to be able to meet the growing
          needs of different industries through the applied cutting-edge
          technology.
        </p>
      </div>
    </section>
    <section id="four">
      <div id="service-details">
        <div id="service-details1">
          <img src="<?php echo get_theme_file_uri('/images/service-details-1.png');?>" alt="" srcset="" />
        </div>
        <div id="service-details2">
          <img src="<?php echo get_theme_file_uri('/images/service-details-2.png');?>" alt="" srcset="" />
        </div>
        <div id="service-details3">
          <img src="<?php echo get_theme_file_uri('/images/service-details-3.png');?>" alt="" srcset="" />
        </div>
        <div id="service-details4">
          <img src="<?php echo get_theme_file_uri('/images/service-details-4.png');?>" alt="" srcset="" />
        </div>
        <div id="service-details5">
          <img src="<?php echo get_theme_file_uri ('/images/service-details-5.png');?>" alt="" srcset="" />
        </div>
      </div>
    </section>
    <section id="five">
      <div id="contact">
        <div id="contact-top">
          <h1>Contact Us</h1>
          <p>
            Need assistance or have a query? Our contact team is just a message
            away. We're committed to providing swift and helpful responses to
            all your inquiries. Get in touch and let us assist you promptly.
          </p>
        </div>
        <div id="contact-bottom">
          <div id="contact-left">
            <form action="">
              <input type="text" name="" id="" />
              <input type="email" name="" id="" />
              <input type="text" name="" id="" />
              <button type="submit">Send</button>
            </form>
          </div>
          <div id="contact-right">
            <img src="<?php echo get_theme_file_uri('/images/Map.png');?>" alt="" srcset="" />
          </div>
        </div>
        </div>

    </section>
    <?php 

  get_footer();

?>