<?php /* Template Name: Blog Page Template */ ?>
<?php get_header(); ?>
<div id="blog-page-heading">
    <p>Blog</p>
    <h1>Describe what <br> your blog is <br> about</h1>
</div>

<?php

while (have_posts()) {
    the_post(); ?>

    <div id="blogs" class="container">
        <div id="blog-post-single">

     
        <?php the_post_thumbnail(); ?>
        <p><?php the_time('F j, Y'); ?> <span id="author"><?php the_author_posts_link(); ?></span></p>
        <h2><?php the_title(); ?></h2>
        <?php echo wp_trim_words( get_the_excerpt(), 10 ); ?></p>
        <button id="our-team-inner-1-right-button"><a href="<?php the_permalink(); ?>">Read More</a></button>
        <!-- <p><a href="http://">Learn More <span><img src="<?php echo get_theme_file_uri('/assets/images/Arrow-dark1.png'); ?>" alt="" srcset=""></span></a></p> -->
        </div>
    </div>

<?php
} ?>
<div id="blog-pagination">
    <?php echo paginate_links(); ?>
</div>


<section id="cta">
    <div id="cta-inner" class="container">
        <div id="cta-inner-left">
            <h2>Let’s Request A Free <br>
                Consultation</h2>
            <p>cupidatat incididunt sint deserunt voluptate aute id deserunt nisi.Aliqua id <br> fugiat nos. minim
                tempor dolore cillum.cu tempor dolore cillum minim <br> upidatatenim. Elit aute irure tempor.</p>
        </div>
        <div id="cta-inner-right">
            <button id="cta-inner-right-button"><a href="http://">Get in touch</a></button>
        </div>
    </div>
</section>
<?php
get_footer();
?>