<?php 
function smith_assets(){
    wp_enqueue_style('main_style', get_theme_file_uri('/assets/css/main-style.css'));
    wp_enqueue_style('theme_style_two',get_theme_file_uri('style.css'));


    if (get_the_ID('8')){
    wp_enqueue_style('woo_style', get_theme_file_uri('/assets/css/woo-style.css'));
    }
}






add_action('wp_enqueue_scripts' ,'smith_assets');







// After theme setup
add_action('after_setup_theme', 'my_theme_setup');

function my_theme_setup(){
    add_theme_support('woocommerce');
}
