<?php get_header(); ?>
<section id="hero" class="container">
        <div id="hero-inner-one">
            <div id="hero-inner-one-text1">
                <h1>We solve your <br> legal Issues <br> properly.</h1>
            </div>
            <div id="hero-inner-one-text2">
                <button id="hero-button"><a href="http://">Button</a></button>
                <h4>Every day, we help international <br> businesses determine how best to <br>structure their domestic
                    and overseas <br> operations.</h4>
            </div>
        </div>
        <div id="hero-inner-two">
            <img src="<?php echo get_theme_file_uri('/assets/images/row.png')?>" class="img-fluid" alt="" srcset="">
        </div>
    </section>
    <section id="numbers" class="container-fluid">
        <div id="number-1">
            <h2>1000+</h2>
            <p>Client Consultations</p>
        </div>
        <div id="number-2">
            <h2>98%</h2>
            <p>Successful Cases</p>
        </div>
        <div id="number-3">
            <h2>10M</h2>
            <p>Recovered cost for clients</p>
        </div>
        <div id="number-4">
            <h2>30+</h2>
            <p>Professional Attorneys</p>
        </div>
    </section>
    <section id="about-us" class="container">
        <div id="about-us-inner-one">
            <div id="about-us-inner-one-text1">
                <p>About us </p>
                <h2>Legally Fights For Your <br> Justice.</h2>
            </div>
            <div id="about-us-inner-one-text2">
                <p>Since the beginning, we believed that <br> software can change the world. <br> Combining agile
                    development with <br> strategic thinking, our digital products <br> and services</p>
                <p id="about-us-inner-one-button">Contact us <span><img src="<?php echo get_theme_file_uri('/assets/images/Arrow 1.png');?>" alt=""
                            srcset=""></span></p>
            </div>

        </div>
        <div id="about-us-inner-two">
            <div id="about-us-inner-two-text1">
                <img src="<?php echo get_theme_file_uri('/assets/images/Courthouse.png');?>" alt="" srcset="">
                <h4>Experienced Court Performance</h4>
                <p>We provide comprehensive legal solutions, <br> including contract drafting and negotiation <br>
                    mergers and acquisitions.</p>
            </div>
            <div id="about-us-inner-two-text2">
                <img src="<?php echo get_theme_file_uri('/assets/images/law.png');?>" alt="" srcset="">
                <h4>We Provide Solid Law Practice</h4>
                <p>We provide comprehensive legal solutions, <br> including contract drafting and negotiation <br>
                    mergers and acquisitions.</p>
            </div>
            <div id="about-us-inner-two-text3">
                <img src="<?php echo get_theme_file_uri('/assets/images/law document.png');?>" alt="" srcset="">
                <h4>Winners For Global Legal Innovation</h4>
                <p>We provide comprehensive legal solutions, <br> including contract drafting and negotiation <br>
                    mergers and acquisitions.</p>
            </div>
        </div>
    </section>
    <section id="choose-us" class="container-fluid">
        <div id="choose-us-inner-1">
            <div id="choose-us-inner-1-text">
                <h4>Why Choose Us?</h4>
                <h2>Community Disband <br> Policy Digital Close <br> Overflow</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed <br> do eiusmod tempor incididunt ut
                    labore et dolore magna <br> aliqua. Ut enim ad minim veniam, </p>
                <button id="choose-us-inner-1-button">
                    <a href="http://">Button</a>
                </button>
            </div>
            <div id="choose-us-inner-1-image">
                <img src="<?php echo get_theme_file_uri('/assets/images/Rectangle 4.png');?>" class="img-fluid" alt="" srcset="">
            </div>
        </div>
        <div id="choose-us-inner-2">
            <div id="choose-us-inner-2-image">
                <img src="<?php echo get_theme_file_uri('/assets/images/Rectangle 4.png');?>" class="img-fluid" alt="" srcset="">
            </div>
            <div id="choose-us-inner-2-text">
                <h2>We Earn Your Trust And <br> Are Diligent In Your <br> Case.</h2>
                <div id="choose-us-inner2-text-details">
                    <p>Free Consultation <span><img src="<?php echo get_theme_file_uri('/assets/images/Arrow 2.png');?>" alt="" srcset=""></span></p>

                    <p>Legal Information <span><img src="<?php echo get_theme_file_uri('/assets/images/Arrow 2.png');?>" alt="" srcset=""></span></p>

                    <p>Proven Results <span><img src="<?php echo get_theme_file_uri('/assets/images/Arrow 2.png');?>" alt="" srcset=""></span></p>

                </div>
            </div>
        </div>
    </section>
    <section id="practice-areas" class="container">
        <div id="practice-areas-heading-text">
            <p>CASE STUDIES</p>
            <h2>Legal Solutions Tailored To <br> Your Needs</h2>
        </div>
        <div id="practice-areas-inner">
            <div id="practice-areas-inner1">
                <div id="practice-areas-inner1-details1">
                    <img src="<?php echo get_theme_file_uri('/assets/images/image 148.png');?>" alt="" srcset="">
                    <h5>Family Law</h5>
                    <p>Lorem ipsum dolor sit amet consectetur. <br> Tellus amet aliquet sit mi arcu id est <br>
                        fringilla. Cursus vulputate</p>
                    <h6>Learn More <span><img src="<?php echo get_theme_file_uri('/assets/images/Arrow 1.png');?>" alt="" srcset=""></span></h6>
                </div>
                <div id="practice-areas-inner1-details2">
                    <img src="<?php echo get_theme_file_uri('/assets/images/image 148-1.png');?>" alt="" srcset="">
                    <h5>Business Law</h5>
                    <p>Lorem ipsum dolor sit amet consectetur. <br> Tellus amet aliquet sit mi arcu id est <br>
                        fringilla. Cursus vulputate</p>
                    <h6>Learn More <span><img src="<?php echo get_theme_file_uri('/assets/images/Arrow 1.png');?>" alt="" srcset=""></span></h6>
                </div>
                <div id="practice-areas-inner1-details3">
                    <img src="<?php echo get_theme_file_uri('/assets/images/image 148-2.png');?>" alt="" srcset="">
                    <h5>Criminal law</h5>
                    <p>Lorem ipsum dolor sit amet consectetur. <br> Tellus amet aliquet sit mi arcu id est <br>
                        fringilla. Cursus vulputate</p>
                    <h6>Learn More <span><img src="<?php echo get_theme_file_uri('/assets/images/Arrow 1.png');?>" alt="" srcset=""></span></h6>
                </div>
            </div>
            <div id="practice-areas-inner2">
                <div id="practice-areas-inner2-details1">
                    <img src="<?php echo get_theme_file_uri('/assets/images/image 149.png');?>" alt="" srcset="">
                    <h5>Real Estate Law</h5>
                    <p>Lorem ipsum dolor sit amet consectetur. <br> Tellus amet aliquet sit mi arcu id est <br>
                        fringilla. Cursus vulputate</p>
                    <h6>Learn More <span><img src="<?php echo get_theme_file_uri('/assets/images/Arrow 1.png');?>" alt="" srcset=""></span></h6>
                </div>
                <div id="practice-areas-inner2-details2">
                    <img src="<?php echo get_theme_file_uri('/assets/images/image 149-1.png')?>" alt="" srcset="">
                    <h5>Tax Law</h5>
                    <p>Lorem ipsum dolor sit amet consectetur. <br> Tellus amet aliquet sit mi arcu id est <br>
                        fringilla. Cursus vulputate</p>
                    <h6>Learn More <span><img src="<?php echo get_theme_file_uri('/assets/images/Arrow 1.png');?>" alt="" srcset=""></span></h6>
                </div>
                <div id="practice-areas-inner2-details3">
                    <img src="<?php echo get_theme_file_uri('/assets/images/image 149-2.png');?>" alt="" srcset="">
                    <h5>Traffic Law</h5>
                    <p>Lorem ipsum dolor sit amet consectetur. <br> Tellus amet aliquet sit mi arcu id est <br>
                        fringilla. Cursus vulputate</p>
                    <h6>Learn More <span><img src="<?php echo get_theme_file_uri('/assets/images/Arrow 1.png');?>" alt="" srcset=""></span></h6>
                </div>
            </div>
        </div>
    </section>
    <section id="testimonials">
        <div id="testimonials-heading">
            <h2>See What Our Clients Have To Say <br> About Us</h2>
        </div>
        <section class="splide" aria-label="Splide Basic HTML Example">
            <div class="splide__track">
                <ul class="splide__list">
                    <li class="splide__slide">
                        <div id="testimonials-client-1">
                            <img src="<?php echo get_theme_file_uri('/assets/images/quotes.png');?>" alt="" srcset="">
                            <p>We were happy that we found the best UI/UX Design agency and <br> best product design
                                agency to work with. We will definitely <br> continue to work with them as we have
                                greatest output.</p>
                        </div>
                        <div id="testimonials-client-1-details">
                            <img src="<?php echo get_theme_file_uri('/assets/images/client-1.png');?>" alt="" srcset="">
                            <h2>Miles, Esther</h2>
                            <p>Co-Founder,</p>
                            <p> Elegant</p>
                        </div>
                    </li>
                    <li class="splide__slide">
                        <h4>Client 2</h4>
                    </li>
                    <li class="splide__slide">
                        <h4>Client 3</h4>
                    </li>
                </ul>
            </div>
        </section>
    </section>
    <section id="our-team" class="container-fluid">
        <div id="our-team-inner">
            <div id="our-team-inner-1">
                <div id="our-team-inner-1-left">
                    <p>OUR TEAM</p>
                    <h2>Meet Our Dedicated Expert <br> Legal Team</h2>
                </div>
                <div id="our-team-inner-1-right">
                    <p>Lorem ipsum dolor sit amet, consectetur <br> adipiscing elit, sed do eiusmod tempor <br>
                        incididunt ut labore et dolore magna aliqua. </p>
                    <button id="our-team-inner-1-right-button"><a href="http://">Button</a></button>
                </div>
            </div>
            <div id="our-team-inner-2">
                <div id="our-team-inner-2-details1">
                    <img src="<?php echo get_theme_file_uri('/assets/images/our-team-1.png');?>" alt="" srcset="">
                    <h4>Darlene Robertson</h4>
                    <h6>Partner</h6>
                    <div id="our-team-inner-2-details1-socials">
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 118.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 117.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 116.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 115.png');?>" alt="" srcset=""></a>
                    </div>
                </div>
                <div id="our-team-inner-2-details2">
                    <img src="<?php echo get_theme_file_uri('/assets/images/our-team-2.png');?>" alt="" srcset="">
                    <h4>Floyd Miles</h4>
                    <h6>Partner</h6>
                    <div id="our-team-inner-2-details2-socials">
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 118.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 117.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 116.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 115.png');?>" alt="" srcset=""></a>
                    </div>
                </div>
                <div id="our-team-inner-2-details3">
                    <img src="<?php echo get_theme_file_uri('/assets/images/our-team-3.png');?>" alt="" srcset="">
                    <h4>Robert Fox</h4>
                    <h6>Partner</h6>
                    <div id="our-team-inner-2-details3-socials">
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 118.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 117.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 116.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 115.png');?>" alt="" srcset=""></a>
                    </div>
                </div>
                <div id="our-team-inner-2-details4">
                    <img src="<?php echo get_theme_file_uri('/assets/images/our-team-4.png');?>" alt="" srcset="">
                    <h4>Bessie Cooper</h4>
                    <h6>Partner</h6>
                    <div id="our-team-inner-2-details4-socials">
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 118.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 117.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 116.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 115.png');?>" alt="" srcset=""></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="cta">
        <div id="cta-inner" class="container">
            <div id="cta-inner-left">
                <h2>Let’s Request A Free <br>
                    Consultation</h2>
                <p>cupidatat incididunt sint deserunt voluptate aute id deserunt nisi.Aliqua id <br> fugiat nos. minim
                    tempor dolore cillum.cu tempor dolore cillum minim <br> upidatatenim. Elit aute irure tempor.</p>
            </div>
            <div id="cta-inner-right">
                <button id="cta-inner-right-button"><a href="http://">Get in touch</a></button>
            </div>
        </div>
    </section>
   <?php get_footer(); ?>