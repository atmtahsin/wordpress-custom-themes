<section id="nine">
      <footer>
        <div id="upper-footer">
          <div id="upper-footer-1">
            <img src="./images/Selleriti_Logo 1.png" alt="" srcset="">
            <p>The End of the Page. <br>
              The Beginning of Your Amazon Story.</p>
          </div>
          <div id="upper-footer-2">
            <h1>Quick Links</h1>
            <ul>
              <li>Services</li>
              <li>About Us</li>
              <li>Cases</li>
              <li>Blog</li>
              <li>Documents</li>
            </ul>
          </div>
          <div id="upper-footer-3">
            <h1>Services</h1>
            <ul>
              <li>PPC Audit</li>
              <li>PPC Campaigns</li>
              <li>Amazon Account Management</li>
              <li>Creation of Advertising Content</li>
              <li>Listing and A+ Content</li>
              <li>SEO Titles and Texts</li>
            </ul>
          </div>
          <div id="upper-footer-4">
            <h1>Follow Us</h1>
            <ul>
              <li>
                <span>
                  <img src="./images/instagram 1.svg" alt="" srcset="">
                  <p>Instagram</p>
                </span>
              </li>
              <li>
                <span>
                  <img src="./images/twitter.png" alt="" srcset="">
                  <p>Twitter</p>
                </span>
              </li>
              <li>
                <span>
                  <img src="./images/01.Facebook.png" alt="" srcset="">
                  <p>Facebook</p>
                </span>
              </li>
              <li>
                <span>
                  <img src="./images/10.Linkedin.png" alt="" srcset="">
                  <p>LinkedIn</p>
                </span>
              </li>
            </ul>
          </div>
        </div>
        <div id="bottom-footer">
          <div id="bottom-footer-inner-1">
            <hr id="hr">
            <p>Selleriti © 2023 All Right Reserved</p>
          </div>
          <div id="bottom-footer-inner-2">
            <span>Terms & Conditions</span>
            <span>Privacy Policy</span>
            <span>Cookies Policy</span>
          </div>
        </div>
      </footer>
    </section>
    <?php wp_footer(); ?>
  </body>
</html>