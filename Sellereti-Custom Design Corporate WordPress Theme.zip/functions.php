<?php 
function sellereti_assets(){
    wp_enqueue_style('main_style', get_theme_file_uri('/css/main-style.css'));
}






add_action('wp_enqueue_scripts','sellereti_assets');

