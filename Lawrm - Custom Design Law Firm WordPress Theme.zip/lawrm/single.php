<?php get_header(); ?>


<div id="blog-post-content" class="container">
    <?php the_content(); ?>
</div>








<div id="single-blog-pagination">
    <?php echo paginate_links(); ?>
</div>
<section id="cta">
    <div id="cta-inner" class="container">
        <div id="cta-inner-left">
            <h2>Let’s Request A Free <br>
                Consultation</h2>
            <p>cupidatat incididunt sint deserunt voluptate aute id deserunt nisi.Aliqua id <br> fugiat nos. minim
                tempor dolore cillum.cu tempor dolore cillum minim <br> upidatatenim. Elit aute irure tempor.</p>
        </div>
        <div id="cta-inner-right">
            <button id="cta-inner-right-button"><a href="http://">Get in touch</a></button>
        </div>
    </div>
</section>
<?php
get_footer();
?>