

<footer>
      <div id="footer">
        <div id="left">
          <img src="./images/footer-logo.png" alt="" srcset="" />
        </div>
        <div id="center">
          <p>Proud co-founders of the Hungarian XR coalition.</p>
        </div>
        <div id="right">
          <div id="footer-right1">
            <p>
              Address: 1023, Bécsi road 3-5. Budapest, Hungary</p>
          </div>
          <div id="footer-right2">
            <p>Office: 1036, Galagonya street 6. Budapest, Hungary</p>
          </div>
          <div id="footer-right3">
            <p>Tender reports</p> 
          </div>
          
          </p>
        </div>
      </div>
    </footer>
    <?php wp_footer(); ?>
  </body>
</html>
