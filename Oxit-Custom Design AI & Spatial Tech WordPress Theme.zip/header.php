<!DOCTYPE html>
<html lang="en">
  <head>
  <?php wp_head(); ?>
   
  </head>
  <body>
    <header>
      <nav>
        <div id="header-logo">
          <img src="<?php echo get_theme_file_uri('./images/header-logo.png');?>" alt="" srcset="" />
        </div>
        <li><a href="#contact">Contact Us</a></li>
      </nav>
    </header>