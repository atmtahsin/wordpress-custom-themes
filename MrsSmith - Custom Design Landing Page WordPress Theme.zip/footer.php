<footer>
            <div id="footer-top">
                <div id="footer-top-1">
                    <h1>Shop Highlights</h1>
                    <li>Women</li>
                    <li>Accessories</li>
                    <li>Bags</li>
                    <li>Men</li>
                    <li>Shoes</li>
                    <li>Clothings</li>
                </div>
                <div id="footer-top-2">
                    <h1>Quick Links</h1>
                    <li>About Us</li>
                    <li>Core Values</li>
                    <li>Careers</li>
                    <li>Press Releases</li>
                    <li>Sitemap</li>
                </div>
                <div id="footer-top-3">
                    <h1>Contact Info</h1>
                    <li>Need Any Help?</li>
                    <li>(+800) 1234 5678 90</li>
                    <li>Address: 502 New Design Str, <br>
                        Melbourne, Australia</li>
                    <li>E-mail: contact@alukas.com</li>
                </div>
                <div id="footer-top-4">
                    <h1>Newsletter</h1>
                    <p>Sign up for our mailing list to get latest Updates and offers.</p>
                    <input type="text" value="">
                    <button id="footer-button">Subscribe</button>
                </div>

            </div>
            <div id="footer-bottom">

            </div>
        </footer>
    </main>
    <?php wp_footer();?>
</body>
</html>