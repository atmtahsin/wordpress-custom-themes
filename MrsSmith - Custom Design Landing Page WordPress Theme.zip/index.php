<?php get_header();?>
        <section id="one">
      
         <div id="slide-bg-one">
            <div id="heading-one">
                <h1>A new line of overalls <br> for the little ones</h1>
                </div>
                <div id="sub-heading-one">
                    <p>How can you evaluate content without design? No typography, no colors, <br>
                        no layout, no styles, all those things that convey the important signals.</p>
                </div>
                <button id="button-hero">
                Shop now
                </button>
         </div>          

   
        </section>
        <section id="two">
            <div>
                <div1 id="circle1">
                    <img src="<?php echo get_theme_file_uri('assets/images/w-bcs-category-growsuit.jpg.png')?>" alt="" srcset="">
                    <button>Growsuits</button>
                </div1>
                <div2 id="circle2">
                    <img src="<?php echo get_theme_file_uri('assets/images/w-bcs-category-jumpers.jpg.png')?>" alt="" srcset="">
                    <button>Jumpers</button>
                </div2>
                <div3 id="circle3">
                    <img src="<?php echo get_theme_file_uri('assets/images/w-bcs-category-toys.jpg.png')?>" alt="" srcset="">
                    <button>Toys</button>
                </div3>
                <div4 id="circle4">
                    <img src="<?php echo get_theme_file_uri('assets/images/w-bcs-category-accessories.jpg.png')?>" alt="" srcset="">
                    <button>Accessories</button>
                </div4>
                <div5 id="circle5">
                    <img src="<?php echo get_theme_file_uri('assets/images/w-bcs-category-dresses.jpg.png')?>" alt="">
                    <button>Dresses</button>
                </div5>
                <div6 id="circle6">
                    <img src="<?php echo get_theme_file_uri('assets/images/w-bcs-category-leggings.jpg.png')?>" alt="" srcset="">
                    <button>Leggings</button>
                </div6>
            </div>
        </section>
        <section id="three">
            <div id="feature-collection-text">
                <p>Discover lots new products</p>
                <h1>Feature collection</h1>
            </div>
            <div id="feature-collection-inner">
                <div id="feature-collection-inner1">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → w-bcs-growsuit-1-1.jpg.png')?>" alt="" srcset="">
                    <p>Zip Growsuit</p>
                    <h6>£30.00</h6>
                </div>
                <div id="feature-collection-inner2">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → Picture → w-bcs-dresses-3-1.jpg.webp.png')?>" alt="" srcset="">
                    <p>Animal Friends Long Sleeve Dress</p>
                    <h6>£44.95</h6>
                </div>
                <div id="feature-collection-inner3">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → w-bcs-jumpers-4-1.jpg.png')?>" alt="" srcset="">
                    <p>Small Rainbow Jumper</p>
                    <h6>£48.00</h6>
                </div>
                <div id="feature-collection-inner4">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → Picture → w-bcs-leggings-3-1.jpg.webp.png')?>" alt="" srcset="">
                    <p>Basic Rib Legging</p>
                    <h6>£25.00</h6>
                </div>
                <div id="feature-collection-inner5">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → Picture → w-bcs-accessories-2-1.jpg.webp.png')?>" alt="" srcset="">
                    <p>3 Pack Baby Socks</p>
                    <h6>£26.00</h6>
                </div>
            </div>
                
        </section>
        <section id="four">
            <div id="organic-left">
                <img src="<?php echo get_theme_file_uri('assets/images/Main → Article.png')?>" alt="" srcset="">
            </div>
            <div id="organic-right">
                <p>Buy bundle and get a 25% discount</p>
                <h4>Organic and safe clothes <br>
                    set for your baby</h4>
                    <div id="organic-right-inner">
                <div id="organic-right-inner-1">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → w-bcs-jumpers-3-1.jpg.png')?>" alt="" srcset="">
                    <p>Polar Bear Jumper</p>
                    <h6>£59.95</h6>
                </div>
                <div id="organic-right-inner-2">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → Picture → w-bcs-leggings-1-1.jpg.webp.png')?>" alt="" srcset="">
                    <p>Bear Paw Arctic Leggings</p>
                    <h6>£39.95</h6>
                </div>
                <div id="organic-right-inner-3">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → Picture → w-bcs-accessories-8-1.jpg.webp.png')?>" alt="" srcset="">
                    <p>Pom Pom Booties</p>
                    <h6>£32.95</h6>
                </div>
            </div>
                <button id="organic-button">Buy bundle now</button>   
                <p>When you buy this set, you save 25%. Discounts and promotions are not cumulative with the current discount.</p>
            </div>
        </section>
        <section id="five">
            <div id="popular-products-text">
                <p>Hots and bestsellers on this week</p>
                <h1>Popular products</h1>
            </div>
            <div id="popular-products-inner">
                <div id="popular-products-inner-1">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → w-bcs-growsuit-2-1.jpg.png')?>" alt="" srcset="">
                    <p>Bunny Quilted Growsuit</p>
                    <h4>£59.95</h4>
                </div>
                <div id="popular-products-inner-2">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → w-bcs-growsuit-6-1.jpg.png')?>" alt="" srcset="">
                    <p>Fluffy Cloud Growsuit</p>
                    <h4>£30.00</h4>
                </div>
                <div id="popular-products-inner-3">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → Picture → w-bcs-dresses-5-1.jpg.webp.png')?>" alt="" srcset="">
                    <p>CFrangipani Embroidered Dress</p>
                    <h4>£44.95</h4>
                </div>
                <div id="popular-products-inner-4">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → Picture → w-bcs-accessories-3-1.jpg.webp.png')?>" alt="" srcset="">
                    <p>Essentials Bib</p>
                    <h4>£12.00</h4>
                </div>
                <div id="popular-products-inner-5">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → Picture → w-bcs-accessories-7-1.jpg.webp.png')?>" alt="" srcset="">
                    <p>Organic Stripe Rib Mittens</p>
                    <h4>£11.25</h4>
                </div>
            </div>
        </section>
        <section id="six">
            <div id="tips-articles-text">
                <p>Advice for young parents</p>
                <h1>Tips and articles</h1>
            </div>
            <div id="tips-articles-inner">
                <div id="tips-articles-inner-1">
                    <img src="<?php echo get_theme_file_uri('assets/images/date (1).png')?>" alt="" srcset="">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → Picture → w-bcs-blog-1.jpg.webp.png')?>" alt="" srcset="">
                    <h4>Types of baby rashes and <br>
                        how to effectively treat them</h4>
                    <p>Using dummy content or fake <br>
                        information in the Web design process <br>
                        can result in products with unreal...</p>
                    <p>Continue reading</p>
                </div>
                <div id="tips-articles-inner-2">
                    <img src="<?php echo get_theme_file_uri('assets/images/date (2).png')?>" alt="" srcset="">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → Picture → w-bcs-blog-2.jpg.webp.png')?>" alt="" srcset="">
                    <h4>How to choose a baby <br>
                        growsuit & onesie?</h4>
                    <p>Websites in professional use templating <br>
                        systems. Commercial publishing <br>
                        platforms and content managem...</p>
                    <p>Continue reading</p>
                </div>
                <div id="tips-articles-inner-3">
                    <img src="<?php echo get_theme_file_uri('/assets/images/date (3).png')?>" alt="" srcset="">
                    <img src="<?php echo get_theme_file_uri('/assets/images/Link → Picture → w-bcs-blog-3.jpg.webp.png')?>" alt="" srcset="">
                    <h4>How to choose a sleeping <br>
                        bag for your little one</h4>
                    <p>This is quite a problem to solve, but just <br>
                        doing without greeking text won't fix it. <br>
                        Using test item...</p>
                    <p>Continue reading</p>
                </div>
                <div id="tips-articles-inner-4">
                    <img src="<?php echo get_theme_file_uri('assets/images/date (4).png')?>" alt="" srcset="">
                    <img src="<?php echo get_theme_file_uri('assets/images/Link → Picture → w-bcs-blog-4.jpg.webp.png')?>" alt="" srcset="">
                    <h4>Safely administering pain <br>
                        relief to your little one</h4>
                    <p>Lorem Ipsum actually is usefull in the <br>
                        design stage as it focuses our attention on <br>
                        places where the ...</p>
                    <p>Continue reading</p>
                </div>
            </div>
        </section>
        <section id="seven">
            <div id="instagram-text">
                <p>kids</p>
                <h1>Our instagram</h1>
                <div id="instagram-inner">
                    <div id="instagram-inner-1">
                        <img src="<?php echo get_theme_file_uri('assets/images/Picture → w-bcs-instagram-1.jpg.webp.png')?>" alt="" srcset="">
                    </div>
                    <div id="instagram-inner-2">
                        <img src="<?php echo get_theme_file_uri('assets/images/Picture → w-bcs-instagram-2.jpg.webp.png')?>" alt="" srcset="">
                    </div>
                    <div id="instagram-inner-3">
                        <img src="<?php echo get_theme_file_uri('assets/images/div.wd-insta-item.png')?>" alt="" srcset="">
                    </div>
                    <div id="instagram-inner-4">
                        <img src="<?php echo get_theme_file_uri('assets/images/Picture → w-bcs-instagram-4.jpg.webp.png')?>" alt="" srcset="">
                    </div>
                    <div id="instagram-inner-5">
                        <img src="<?php echo get_theme_file_uri('assets/images/Picture → w-bcs-instagram-5.jpg.webp.png')?>" alt="" srcset="">
                    </div>
                </div>
            </div>
        </section>
<?php get_footer();?>