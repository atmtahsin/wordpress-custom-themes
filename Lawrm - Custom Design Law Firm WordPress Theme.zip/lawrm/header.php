<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <?php wp_head(); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>lawrm</title>
</head>

<body>
    <header>

        <div id="header-menu">
            <nav class="navbar navbar-expand-lg bg-body-dark bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand text-light" id="logo-text" href="#"><span><img
                                src="<?php echo get_theme_file_uri('/assets/images/Group 10.png');?>" alt="" srcset=""></span>Lawrm</a>
                    <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                        aria-label="Toggle navigation bg-light">
                        <span class="navbar-toggler-icon bg-light"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                        <div class="navbar-nav bg-body-dark">
                            <a class="nav-link text-light active" aria-current="page" href="<?php echo site_url();?>">Home</a>
                            <a class="nav-link text-light" href="#">About Us</a>
                            <a class="nav-link text-light" href="#">Practice Areas</a>
                            <a class="nav-link text-light" href="#">Contact Us</a>
                            <a class="nav-link text-light" href="<?php echo site_url('/blog');?>">Blog</a>
                            <span class="navbar-text">
                                <p>Call : +125 8767 9687</p>
                            </span>
                        </div>

                    </div>

                </div>

            </nav>

        </div>

        <div id="header-search">
            <img src="./assets/images/search-icon.png" alt="" srcset="">
        </div>
        <div id="header-cart">
            <img src="./assets/images/cart-icon.png" alt="" srcset="">
        </div>


    </header>