<?php

function oxit_files() {
  wp_enqueue_style('oxit_main_styles', get_stylesheet_uri());
}

add_action('wp_enqueue_scripts', 'oxit_files');