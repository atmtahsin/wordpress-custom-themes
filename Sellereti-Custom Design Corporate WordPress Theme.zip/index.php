<?php get_header(); ?>
    <section id="one">
      <div id="hero">
        <div id="hero-inner1">
            <h1> <span id="font-style-change1">Boost</span> Brands & Profits</h1>
            <h2>With Amazon PPC Big Data Analytics <br>
              and Creative Marketing Strategies</h2>
              <p>Avoid trial and error. Embark on a defined journey toward <br>
                growth with Selleriti now</p>
                <button>Request a call with an expert</button>
        </div>
        <div id="hero-inner2">
           <img src="<?php echo get_theme_file_uri('/images/Hero img.png');?>" alt="" srcset="">
        </div>
      </div>
    </section>
    <section id="two">
      <div id="trusted-partner">
        <div id="trusted-partner-inner1">
          <h1>Your <span>Trusted Partner</span> in PPC Strategy <span id="space-left"> <br>
            and Brand Growth </span> </h1>
        </div>
        <div id="trusted-partner-inner2">
          <div id="trusted-partner-inner2-1">
             <h1>82%</h1>
             <span><img src="<?php echo get_theme_file_uri('/images/growth 1.svg');?>" alt="" srcset=""></span>
             <hr>
              <p>Average annual profit growth of <br> our partners</p>
            </div>
          <div id="trusted-partner-inner2-2">
            <h1>200+</h1>
            <span><img src="<?php echo get_theme_file_uri('/images/shopping-cart 1.svg');?>" alt="" srcset=""></span>
            <hr> 
            <p>Orders received</p> 
          </div>
          <div id="trusted-partner-inner2-3">
            <h1>$5.52 <span id="font-style-change2">mln</span></h1>
            <span><img src="<?php echo get_theme_file_uri('/images/investment 1.svg');?>" alt="" srcset=""></span>
            <hr>
            <p>Million Revenue Managed</p>
          </div>
          <div id="trusted-partner-inner2-4">
           <h1>94.5%</h1>
           <span><img src="<?php echo get_theme_file_uri('/images/user-avatar 1.svg');?>" alt="" srcset=""></span>
          <hr>
           <p>Client retention rate</p>
          </div>
        </div>
      </div>
    </section>
    <section id="three">
      <div id="key-features">
        <div id="key-features-inner1">
          <h1><span>Why</span> Selleriti is <span>Your Key to Success</span></h1>
        </div>
        <div id="key-features-inner2">
          <div id="key-features-inner2-1">
            <img src="<?php echo get_theme_file_uri('/images/Group 35.png');?>" alt="" srcset="">
            <h2>Expert 
              Partnership</h2>
            <p>We are 100% committed to our work and treat your business as our own! We collaborate with both established brands with monthly turnovers exceeding $1,000,000 and those who are just starting their journey on Amazon.</p>
          </div>
          <div id="key-features-inner2-2">
            <img src="<?php echo get_theme_file_uri('/images/Rectangle 36.png');?>" alt="" srcset="">
            <h2>Expert Marketing 
              & Advanced software</h2>
            <p>We have developed a unique setup system called "SkyRocket"; our system is a synergy of marketing expertise and advanced software, which, in 87% of cases, increases brand profits by 37% within the first three months!</p>
          </div>
          <div id="key-features-inner2-3">
            <img src="<?php echo get_theme_file_uri('/images/Group 37.png');?>" alt="" srcset="">
            <h2>Monitoring
              & communication</h2>
            <p>We closely monitor the state of your account, ensuring continuous oversight and making adjustments as necessary to keep your Amazon business moving confidently
              forward!</p>
          </div>
         
        </div>
      </div>
    </section>
    <section id="four">
      <div id="selleriti-slider">
        <h1><span>Transforming Brands</span> into Leaders
          Since <span>2019</span></h1>
          <img src="<?php echo get_theme_file_uri('/images/Rectangle 36.png');?>" alt="" srcset="">
          <div id="selleriti-slider-bottom">
            <span>
              <img src="<?php echo get_theme_file_uri('/images/Rectangle 69.png');?>" alt="" srcset="">
           </span>
           <span>
             <img src="<?php echo get_theme_file_uri('/images/Rectangle 70.png');?>" alt="">
           </span>
           <span>
             <img src="<?php echo get_theme_file_uri('/images/Rectangle 70.png');?>" alt="">
           </span>
           <span>
             <img src="<?php echo get_theme_file_uri('/images/Rectangle 70.png');?>" alt="">
           </span>
           <span>
             <img src="<?php echo get_theme_file_uri('/images/Rectangle 70.png');?>" alt="">
           </span>
           <span>
             <img src="<?php echo get_theme_file_uri('/images/Rectangle 70.png');?>" alt="">
           </span>
           <span>
             <img src="<?php echo get_theme_file_uri('/images/Rectangle 70.png');?>" alt="">
           </span>
          </div>
      </div>
    </section>
    <section id="five">
      <div id="main-services">
        <div id="main-services-inner1">
          <h1>Our <span>Services</span></h1>
          <img src="<?php echo get_theme_file_uri('/images/Frame.png');?>" alt="" srcset="">
        </div>
        <div id="main-services-inner2">
          <ol>
            <li>
              <p>PPC Audit</p>
              <hr>
              <span><img src="<?php echo get_theme_file_uri('/images/Vector.png');?>" alt="" srcset=""></span>
            </li>
            <li>
              <p>Creation and Management of PPC Campaigns</p>
              <hr>
              <span><img src="<?php echo get_theme_file_uri('/images/Vector.png');?>" alt="" srcset=""></span>
            </li>
            <li>
              <p>Comprehensive Amazon Account Management</p>
              <hr>
              <span><img src="<?php echo get_theme_file_uri('/images/Vector.png');?>" alt="" srcset=""></span>
            </li>
            <li>
              <p>Creation of Advertising Content (Exclusive for Our Clients)</p>
              <hr>
              <span><img src="<?php echo get_theme_file_uri('/images/Vector.png');?>" alt="" srcset=""></span>
            </li>
            <li>
              <p>Creation and Optimization of Listing and A+ Content</p>
              <hr>
              <span><img src="<?php echo get_theme_file_uri('/images/Vector.png');?>" alt="" srcset=""></span>
            </li>
            <li>
              <p>Creation and Optimization of SEO Titles and Texts</p>
              <hr>
              <span><img src="<?php echo get_theme_file_uri('/images/Vector.png');?>" alt="" srcset=""></span>
            </li>
          </ol>
        </div>
      </div>
    </section>
    <section id="six">
      <div id="work-steps">
        <div id="work-steps-inner1">
          <h1>Our <span>Next Steps</span></h1>
          <p>Forget the complexities of marketing. Trust the professionals and focus on what matters most - your <br>business. Apply today and receive a complimentary analysis of your strategy.</p>
        </div>
        <div id="work-steps-inner2">
          <div id="work-steps-inner2-1">
            <div id="each-step">
              <span>01</span>
              <h4>Audit Request</h4>
              </div>
              <div id="each-step">
                <span>02</span>
              <h4>Complimentary Audit</h4>
            </div>
            <div id="work-steps-inner2-span">
          <ul>
            <li>
              <img src="<?php echo get_theme_file_uri('/images/Vector1.png');?>" alt="" srcset="">
              <span id="work-steps-inner2-1"><img src="<?php echo get_theme_file_uri('/images/Ellipse 2631.png');?>" alt="" srcset=""> <p id="work-steps-inner2-span1">Competitor and Niche Analysis</p></span>
              <span id="work-steps-inner2-2"><img src="<?php echo get_theme_file_uri('/images/Ellipse 2631.png');?>" alt="" srcset=""> <p id="work-steps-inner2-span2">Listing Verification</p></span>
              <span id="work-steps-inner2-3"><img src="<?php echo get_theme_file_uri('/images/Ellipse 2631.png');?>" alt="" srcset=""> <p id="work-steps-inner2-span3">Advertising Campaign Audit</p></span>
              <span id="work-steps-inner2-4"><img src="<?php echo get_theme_file_uri('/images/Ellipse 2631.png');?>" alt="" srcset=""> <p id="work-steps-inner2-span4">Audit Report</p></span>
            </li>
          </ul>
        </div>
          <div id="each-step">
            <span>03</span>
              <h4>Growth Strategy</h4>
          </div>
          <div id="work-steps-inner2-2">
            <div id="each-step">
             <span>04</span>
              <h4>Our Services</h4>
            </div>
            <div id="each-step">
              <span>05</span>
              <h4>Weekly Analytical Report</h4>
            </div>
            <div id="each-step">
                <span>06</span>
              <h4>Progress After a Month of Collaboration</h4>
            </div>
            <div id="each-step">
              <span>07</span>
              <h4>Record Sales Growth</h4>
        </div>
        </div>
      </div>
      </div>
      </div>
    </section>
    <section id="seven">
      <div id="partners-testimonials">
        <div id="partners-testimonials-inner1">
          <h1>Selleriti Partners <span>Testimonials</span></h1>
        </div>
        <div id="partners-testimonials-inner2">
          <div id="partners-testimonials-inner2-1">
            <h4>Amazon PPC</h4>
            <span><img src="<?php echo get_theme_file_uri('/images/quote.png');?>" alt="" srcset=""></span>
            <p>Mar 4, 2021 - Aug 1, 2023</p>
            <p>"Selleriti is an excellent agency for managing Amazon ads. Very trustworthy and knowledgeable."</p>
          </div>
          <div id="partners-testimonials-inner2-2">
            <h4>Amazon PPC Management</h4>
            <span><img src="<?php echo get_theme_file_uri('/images/quote.png');?>" alt="" srcset=""></span>
            <p>Jul 8, 2022 - Jun 7, 2023</p>
            <p>"The team at Selleriti has been incredibly professional. They are skilled Amazon marketers who took complete control of our Amazon account, launched hundreds...</p>
          </div>
          <div id="partners-testimonials-inner2-3">
            <h4>Amazon Ads Specialists for KDP Books Launch</h4>
            <span><img src="<?php echo get_theme_file_uri('/images/quote.png');?>" alt="" srcset=""></span>
             <p>Aug 2, 2022 - May 26, 2023</p>
             <p>"Selleriti has done an excellent job helping my account grow. I chose them for their seriousness and competence. My previous manager couldn't handle ads properly...</p>            
          </div>
        </div>
        <span>
          <img src="<?php echo get_theme_file_uri('/images/Rectangle 69.png');?>" alt="" srcset="">
       </span>
       <span>
         <img src="<?php echo get_theme_file_uri('/images/Rectangle 70.png');?>" alt="">
       </span>
       <span>
         <img src="<?php echo get_theme_file_uri('/images/Rectangle 70.png');?>" alt="">
       </span>
       <span>
         <img src="<?php echo get_theme_file_uri('/images/Rectangle 70.png');?>" alt="">
       </span>
       <span>
         <img src="<?php echo get_theme_file_uri('/images/Rectangle 70.png');?>" alt="">
       </span>
       <span>
         <img src="<?php echo get_theme_file_uri('/images/Rectangle 70.png');?>" alt="">
       </span>
       <span>
         <img src="<?php echo get_theme_file_uri('/images/Rectangle 70.png');?>" alt="">
       </span>
      </div>
    </section>
    <section id="eight">
      <div id="selleriti-cta">
        
        <div id="cta-inner-1">
          <h1>Reach New Heights <br> <span>in Sales with Us</span></h1>
          <p>Contact us or schedule a call at a time convenient for you with <br> an Amazon PPC and marketing expert.</p>
          <button id="button1">Contact Us</button>
          <button id="button2">Schedule a call</button>
        </div>
        <div id="cta-inner-2">
          <iframe src="https://calendar.google.com/calendar/embed?height=600&wkst=1&ctz=Asia%2FDhaka&bgcolor=%23ffffff&src=aWduaXNsdXBpbmVAZ21haWwuY29t&src=YWRkcmVzc2Jvb2sjY29udGFjdHNAZ3JvdXAudi5jYWxlbmRhci5nb29nbGUuY29t&src=ZW4uYmQjaG9saWRheUBncm91cC52LmNhbGVuZGFyLmdvb2dsZS5jb20&src=a242OXRodHJocnNrYzJscnZhMW9odnU2c3V2c2x0Z2pAaW1wb3J0LmNhbGVuZGFyLmdvb2dsZS5jb20&color=%23039BE5&color=%2333B679&color=%230B8043&color=%23795548" style="padding: 30px;" width="400" height="400" frameborder="0" scrolling="no"></iframe>
        </div>
      </div>
    </section>
    
    <?php get_footer(); ?>