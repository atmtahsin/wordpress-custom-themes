<?php



function lawrm_assets(){
    wp_enqueue_style('bootstrap-css', get_theme_file_uri('/assets/css/bootstrap.min.css'));
    wp_enqueue_style('splide-css', get_theme_file_uri('/assets/css/splide.min.css'));
    wp_enqueue_style('main-css', get_theme_file_uri('/assets/css/main-style.css'));
    wp_enqueue_style('theme-css', get_stylesheet_uri());
    wp_enqueue_script('bootstrap-js', get_theme_file_uri('/assets/js/bootstrap.min.js'));
    wp_enqueue_script('splide-js', get_theme_file_uri('/assets/js/splide.min.js'));
    wp_enqueue_script('splide-script', get_theme_file_uri('/assets/js/splide-script.js'));
}
add_action('wp_enqueue_scripts','lawrm_assets');

add_theme_support( 'post-thumbnails' );

