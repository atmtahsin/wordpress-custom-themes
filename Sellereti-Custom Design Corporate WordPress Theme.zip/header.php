<!DOCTYPE html>
<html lang="en">
  <head>
<?php wp_head();?>
    <title>Sellereti</title>
  </head>
  <body>
    <header>
      <div id="main-nav">
        <div id="main-nav-left">
          <img src="./images/Selleriti_Logo 1.png" alt="" srcset="">
        </div>
        <div id="main-nav-center">
          <ul>
            <li><a href="">Cases</a></li>
            <li><a href="">Services</a></li>
            <li><a href="">About Us</a></li>
            <li><a href="">Blog</a></li>
            <li><a href="">Contacts</a></li>
            <li><a href="">Documents</a></li>
          </ul>
        </div>
        <div id="main-nav-right">
          <span>En</span>
          <span>Ua</span>
          <span>Ru</span>
          <button>Contact Us</button>
        </div>
      </div>
    </header>