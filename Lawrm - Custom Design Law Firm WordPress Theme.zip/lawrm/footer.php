<footer>
        <div id="footer-inner" class="container">
            <div id="footer-inner-1">
                <div id="footer-inner-1-details1">
                    <h2><img src="<?php echo get_theme_file_uri('/assets/images/Group 10 (1).png'); ?>" alt="" srcset="">Lawrm</h2>
                </div>
                <div id="footer-inner1-details2">
                    <h4>Subscribe to News</h4>
                    <input type="text" value="Email">
                </div>

            </div>
            <div id="footer-inner-2">
                <ul>
                    <h2>Pages</h2>
                    <li><a href="http://">Home 1</a></li>
                    <li><a href="http://">Home 2</a></li>
                    <li><a href="http://">Contact Us</a></li>
                    <li><a href="http://">About Us</a></li>
                </ul>
                <ul>
                    <h2>All Pages</h2>
                    <li><a href="http://">Link 1</a></li>
                    <li><a href="http://">Link 2</a></li>
                    <li><a href="http://">Link 3</a></li>
                    <li><a href="http://">Link 4</a></li>
                    <li><a href="http://">Link 5</a></li>
                </ul>
                <ul>
                    <h2>CMS Pages</h2>
                    <li><a href="http://">Link 1</a></li>
                    <li><a href="http://">Link 2</a></li>
                    <li><a href="http://">Link 3</a></li>
                    <li><a href="http://">Link 4</a></li>
                    <li><a href="http://">Link 5</a></li>
                </ul>
                <div id="footer-inner-2-contact">
                    <h4>Contact</h4>
                    <h4>3891 Ranchview Dr. Richardson, California 62639</h4>
                    <h4>+123 4465 696</h4>
                    <div id="footer-inner-2-contact-socials">
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 110.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 111.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 112.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 113.png');?>" alt="" srcset=""></a>
                        <a href="http://"><img src="<?php echo get_theme_file_uri('/assets/images/Frame 114.png');?>" alt="" srcset=""></a>
                    </div>
                </div>
            </div>
            <div id="footer-inner-3">
                <h1>cantactinfo@Gmail.com</h1>
            </div>
            <div id="footer-inner-4">
                <div id="footer-inner-4-left">
                    <p>Privacy Policy</p>
                    <p>Terms of Service</p>
                    <p>Cookies Settings</p>
                </div>
                <div id="footer-inner-4-right">
                    <p>2022 Relume. All right reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <?php wp_footer(); ?>
</body>

</html>